package edu.java.homework;

public class MemberService {
	
	public boolean login(String id, String pw) {
		if(id =="test" && pw == "1234") {
			return true;
		}
		return false;
	}
	public boolean logout(String id) {
		if(id == "test"){
			System.out.println("test님이 로그아웃 되었습니다");
			return true;
			
		}
		return false;
	}

}
