package edu.java.homework;

public class Printer {
	
	public int println(int i) {
		System.out.println(i);
		return i;
	}
	public boolean println(boolean b) {
		System.out.println(b);
		return b;
	}
	public double println(double d) {
		System.out.println(d);
		return d;
	}
	public String println(String str) {
		System.out.println(str);
		return str;
	}
}
